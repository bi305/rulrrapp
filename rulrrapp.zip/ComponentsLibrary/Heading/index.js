import { Typography } from "@mui/material";
import React from "react";

const Heading = () => {
	return (
		<>
			<Typography></Typography>
		</>
	);
};

export default Heading;
