import { Button } from "@mui/material";
import React from "react";

const StoreButton = ({}) => {
	return (
		<>
			<Button>StoreButton</Button>
		</>
	);
};

export default StoreButton;
