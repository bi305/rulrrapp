import { Grid } from "@mui/material";
import { Box } from "@mui/system";
import React from "react";

const Footer = () => {
	return (
		<Box>
			<Grid container>
				<Grid item md={2}>
					footer
				</Grid>
				<Grid item md={2}>
					footer
				</Grid>
				<Grid item md={2}>
					footer
				</Grid>
				<Grid item md={2}>
					footer
				</Grid>
				<Grid item md={2}>
					footer
				</Grid>
				<Grid item md={2}>
					footer
				</Grid>
			</Grid>
		</Box>
	);
};

export default Footer;
